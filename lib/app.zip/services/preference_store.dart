import 'package:flutter_secure_storage/flutter_secure_storage.dart';

/// Lightweight secure preferences (language, notification opt-in).
///
/// Reuses [FlutterSecureStorage] — no new packages.
class PreferenceStore {
  const PreferenceStore({FlutterSecureStorage? storage})
      : _storage = storage ?? const FlutterSecureStorage();

  static const langKey = 'sirati_lang';
  static const notificationsKey = 'sirati_notifications_enabled';
  static const onboardingKey = 'sirati_onboarding_completed';
  static const themeModeKey = 'sirati_theme_mode';

  final FlutterSecureStorage _storage;

  Future<String?> readLanguage() => _storage.read(key: langKey);

  Future<void> saveLanguage(String code) =>
      _storage.write(key: langKey, value: code == 'en' ? 'en' : 'ar');

  /// Defaults to enabled when unset.
  Future<bool> readNotificationsEnabled() async {
    final raw = await _storage.read(key: notificationsKey);
    if (raw == null) return true;
    return raw != '0' && raw.toLowerCase() != 'false';
  }

  Future<void> saveNotificationsEnabled(bool enabled) =>
      _storage.write(key: notificationsKey, value: enabled ? '1' : '0');

  /// First-run product tour. Missing key → not completed.
  Future<bool> readOnboardingCompleted() async {
    final raw = await _storage.read(key: onboardingKey);
    if (raw == null) return false;
    return raw == '1' || raw.toLowerCase() == 'true';
  }

  Future<void> saveOnboardingCompleted(bool completed) =>
      _storage.write(key: onboardingKey, value: completed ? '1' : '0');

  /// Appearance: `system` | `light` | `dark`. Missing → system.
  Future<String?> readThemeMode() => _storage.read(key: themeModeKey);

  Future<void> saveThemeMode(String mode) {
    final normalized = (mode == 'light' || mode == 'dark' || mode == 'system')
        ? mode
        : 'system';
    return _storage.write(key: themeModeKey, value: normalized);
  }
}
