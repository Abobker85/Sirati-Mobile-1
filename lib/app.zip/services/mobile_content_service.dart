import '../app_locale.dart';
import 'api_client.dart';
import 'auth_token_store.dart';

/// Short-lived in-memory cache for mobile content endpoints.
/// TTL keeps data feeling instant on tab revisit without going stale for long.
class _CacheEntry {
  final Map<String, dynamic> data;
  final DateTime at;

  const _CacheEntry(this.data, this.at);

  bool isFresh([Duration ttl = MobileContentService.cacheTtl]) =>
      DateTime.now().difference(at) < ttl;
}

class MobileContentService {
  MobileContentService({ApiClient? apiClient})
      : _apiClient = apiClient ??
            ApiClient(tokenProvider: const AuthTokenStore().readToken);

  final ApiClient _apiClient;

  /// Shared process-wide cache (service is often re-created per call site).
  static final Map<String, _CacheEntry> _cache = {};

  static const cacheTtl = Duration(seconds: 60);

  /// Drop cache entries. Pass a key prefix like `dashboard:` or `my-cvs:`.
  static void invalidate([String? keyPrefix]) {
    if (keyPrefix == null || keyPrefix.isEmpty) {
      _cache.clear();
      return;
    }
    _cache.removeWhere((key, _) => key.startsWith(keyPrefix));
  }

  /// After create / update / delete of CVs so Home + My CVs don't show stale counts.
  static void invalidateCvRelated() {
    invalidate('my-cvs');
    invalidate('dashboard');
  }

  Future<Map<String, dynamic>> dashboard(
    bool english, {
    bool force = false,
  }) {
    return _cached(
      'dashboard:${_lang(english)}',
      force: force,
      fetch: () async {
        final response = await _apiClient
            .getJson('/mobile/dashboard?lang=${_lang(english)}');
        return _data(response);
      },
    );
  }

  Future<Map<String, dynamic>> myCvs(
    bool english, {
    bool force = false,
  }) {
    return _cached(
      'my-cvs:${_lang(english)}',
      force: force,
      fetch: () async {
        final response =
            await _apiClient.getJson('/mobile/my-cvs?lang=${_lang(english)}');
        return _data(response);
      },
    );
  }

  Future<Map<String, dynamic>> education(
    bool english, {
    String type = 'study',
    bool force = false,
  }) {
    return _cached(
      'education:${_lang(english)}:$type',
      force: force,
      fetch: () async {
        final response = await _apiClient
            .getJson('/mobile/education?lang=${_lang(english)}&type=$type');
        return _data(response);
      },
    );
  }

  Future<Map<String, dynamic>> educationContent(int id, bool english) async {
    final response = await _apiClient
        .getJson('/mobile/education/$id?lang=${_lang(english)}');
    return _data(response);
  }

  Future<Map<String, dynamic>> jobNews(
    bool english, {
    String? category,
    String? query,
    bool force = false,
  }) {
    final cat = category ?? '';
    final q = query?.trim() ?? '';
    return _cached(
      'job-news:${_lang(english)}:$cat:$q',
      force: force,
      // Search queries: shorter usefulness; still cache briefly.
      ttl: q.isEmpty ? cacheTtl : const Duration(seconds: 30),
      fetch: () async {
        final params = <String, String>{'lang': _lang(english)};
        if (cat.isNotEmpty) params['category'] = cat;
        if (q.isNotEmpty) params['q'] = q;
        final response = await _apiClient
            .getJson('/mobile/job-news?${Uri(queryParameters: params).query}');
        return _data(response);
      },
    );
  }

  Future<Map<String, dynamic>> jobNewsItem(int id, bool english) async {
    final response =
        await _apiClient.getJson('/mobile/job-news/$id?lang=${_lang(english)}');
    return _data(response);
  }

  Future<Map<String, dynamic>> notifications({bool force = false}) {
    return _cached(
      'notifications',
      force: force,
      ttl: const Duration(seconds: 30),
      fetch: () async {
        final response = await _apiClient.getJson('/mobile/notifications');
        return _data(response);
      },
    );
  }

  Future<Map<String, dynamic>> markNotificationRead(int id) async {
    final response =
        await _apiClient.postJson('/mobile/notifications/$id/read', const {});
    invalidate('notifications');
    return _data(response);
  }

  Future<void> markAllNotificationsRead() async {
    await _apiClient.postJson('/mobile/notifications/read-all', const {});
    invalidate('notifications');
  }

  Future<Map<String, dynamic>> _cached(
    String key, {
    required Future<Map<String, dynamic>> Function() fetch,
    bool force = false,
    Duration ttl = cacheTtl,
  }) async {
    final cached = _cache[key];
    if (!force && cached != null && cached.isFresh(ttl)) {
      return cached.data;
    }

    try {
      final data = await fetch();
      _cache[key] = _CacheEntry(data, DateTime.now());
      return data;
    } catch (error) {
      // Prefer last good payload over a hard fail when offline.
      if (cached != null) return cached.data;
      rethrow;
    }
  }

  String _lang(bool english) => english ? 'en' : 'ar';

  Map<String, dynamic> _data(Map<String, dynamic> response) {
    final data = response['data'];
    return data is Map<String, dynamic> ? data : const {};
  }
}

bool mobileContentEnglishFromContext(context) => AppLocale.isEnglish(context);
